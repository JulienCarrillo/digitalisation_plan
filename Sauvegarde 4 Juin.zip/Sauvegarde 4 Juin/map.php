<?php 


// Connexion base de donnée 
try
{
        $db = new PDO('mysql:host=localhost;dbname=test', 'root', 'root');
}
catch(Exception $e)
{
            die('Erreur : '.$e->getMessage());
}


$reponse= $db->query('SELECT * FROM RDC');


  session_start();
 include("config.php");
 include("fonction.php");

 $mapData = getMapData($_GET['etage']);

 $img = $mapData['img'];
 $blockDatas = $mapData['blocks'];


?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="RDC.css">
	<meta charset="utf-8">
	<title>RDC</title>
</head>

<body>
	<header>
		<?php
			include 'menu.php';

		?>
	</header>
<!--Par convention : blockwraper = ensemble des blocks -->
<div class="blockwraper" >
		<div class="lesblocks" style="background-image: url(<?php echo $img?>)">
			<?php
			//pour chaque "blockData"s
				foreach ($blockDatas as $block) {
					$blockInfos = getBlockInfo($block['ID']);

					?>

				<div class="block" style="left: <?php echo $block['left'] ?>%; top: <?php echo $block['top'] ?>%; width: <?php echo($block['width'])?>%; height: <?php echo($block['height'])?>%; background-color: <?php echo($block['color'])?>" onclick="javascript: alert(<?php echo "'BENCH ".$blockInfos['ID']." : O.E ".$blockInfos['bench'][0]." brassé sur le port ".$blockInfos['switch'].";O.E ".$blockInfos['bench'][1]." brassé sur le port ".$blockInfos['switch']."; O.E ".$blockInfos['bench'][2]." brassé sur le port ".$blockInfos['switch']." du switch Alcatel'"?>)">
				</div>
					<?php
				}
			?>

		

	</div>
</div>



</body>	

</html>