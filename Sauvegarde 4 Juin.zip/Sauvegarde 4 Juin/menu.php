<div class="fondmenu">
			<ul class="menu">
				<li class="img"><img src="logosqli.png"></li>
				<li><a href="http://localhost:8888/V3/map.php?etage=1">RDC</a></li>
				<li><a href="http://localhost:8888/V3/map.php?etage=2">Etage 1</a></li>
				<li><a href="http://localhost:8888/V3/map.php?etage=3">Etage 2</a></li>
				<li><a href="http://localhost:8888/V3/modifier.php"> Modifier</a></li>
				<li><a href="http://localhost:8888/V3/loginV3.php">Déconnexion</a></li>
			</ul>
		</div>